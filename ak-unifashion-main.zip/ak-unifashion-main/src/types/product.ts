export const CATEGORIES = [
  { id: 'shoes', name: 'Shoes', icon: '👟' },
  { id: 'sandals', name: 'Sandals', icon: '🩴' },
  { id: 'watches', name: 'Watches', icon: '⌚' },
  { id: 'perfumes', name: 'Perfumes', icon: '🧴' },
  { id: 'ladies-suits', name: "Ladies Suits", icon: '👗' },
  { id: 'mens-pants-shirts', name: "Men's Pants & Shirts", icon: '👔' },
] as const;

export type CategoryId = typeof CATEGORIES[number]['id'];

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  stock: number;
  featured: boolean;
}

export interface ContactInfo {
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
}
