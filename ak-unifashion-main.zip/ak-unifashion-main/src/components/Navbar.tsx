import { Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import logo from '@/assets/logo.png';

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { isAdmin } = useAuth();

  const links = [
    { to: '/', label: 'Home' },
    { to: '/categories', label: 'Shop' },
    { to: '/contact', label: 'Contact' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
      <div className="container mx-auto px-4 flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2">
          <img src={logo} alt="AK UNIFASHION" className="h-8 w-8 rounded" />
          <span className="font-display text-xl font-bold tracking-wide">AK UNIFASHION</span>
        </Link>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {links.map(l => (
            <Link
              key={l.to}
              to={l.to}
              className={`text-sm font-medium tracking-wider uppercase transition-colors hover:text-gold ${location.pathname === l.to ? 'text-gold' : 'text-foreground'}`}
            >
              {l.label}
            </Link>
          ))}
          {isAdmin && (
            <Link to="/admin" className="text-sm font-medium tracking-wider uppercase text-gold hover:text-gold-dark transition-colors">
              Admin
            </Link>
          )}
          {!isAdmin && (
            <Link to="/admin/login" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Login
            </Link>
          )}
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden p-2" onClick={() => setOpen(!open)}>
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-border bg-background px-4 py-4 space-y-3">
          {links.map(l => (
            <Link
              key={l.to}
              to={l.to}
              onClick={() => setOpen(false)}
              className={`block text-sm font-medium tracking-wider uppercase ${location.pathname === l.to ? 'text-gold' : 'text-foreground'}`}
            >
              {l.label}
            </Link>
          ))}
          {isAdmin ? (
            <Link to="/admin" onClick={() => setOpen(false)} className="block text-sm font-medium text-gold">Admin</Link>
          ) : (
            <Link to="/admin/login" onClick={() => setOpen(false)} className="block text-sm text-muted-foreground">Login</Link>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
