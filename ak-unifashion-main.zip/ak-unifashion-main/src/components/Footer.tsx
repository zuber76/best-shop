import { Link } from 'react-router-dom';
import { useStore } from '@/context/StoreContext';
import logo from '@/assets/logo.png';

const Footer = () => {
  const { contactInfo } = useStore();

  return (
    <footer className="bg-primary text-primary-foreground mt-auto">
      <div className="container mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <img src={logo} alt="AK UNIFASHION" className="h-8 w-8 rounded" />
            <span className="font-display text-lg font-bold tracking-wide">AK UNIFASHION</span>
          </div>
          <p className="text-sm text-primary-foreground/70">Curated fashion for the modern individual. Quality, style, and elegance.</p>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold tracking-wider uppercase mb-4 text-gold">Quick Links</h4>
          <div className="space-y-2 text-sm">
            <Link to="/" className="block text-primary-foreground/70 hover:text-gold transition-colors">Home</Link>
            <Link to="/categories" className="block text-primary-foreground/70 hover:text-gold transition-colors">Shop</Link>
            <Link to="/contact" className="block text-primary-foreground/70 hover:text-gold transition-colors">Contact</Link>
          </div>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold tracking-wider uppercase mb-4 text-gold">Contact</h4>
          <div className="space-y-2 text-sm text-primary-foreground/70">
            <p>{contactInfo.phone}</p>
            <p>{contactInfo.email}</p>
            <p>{contactInfo.address}</p>
          </div>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10 py-4 text-center text-xs text-primary-foreground/50">
        © {new Date().getFullYear()} AK UNIFASHION. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
