import { Link } from 'react-router-dom';
import { Product } from '@/types/product';

const ProductCard = ({ product }: { product: Product }) => (
  <Link to={`/product/${product.id}`} className="fashion-card group">
    <div className="aspect-square overflow-hidden bg-secondary">
      <img
        src={product.images[0]}
        alt={product.name}
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        loading="lazy"
      />
    </div>
    <div className="p-4">
      <h3 className="font-display text-sm font-semibold truncate">{product.name}</h3>
      <p className="text-gold font-body font-semibold mt-1">${product.price.toFixed(2)}</p>
      {product.stock < 5 && product.stock > 0 && (
        <p className="text-xs text-destructive mt-1">Only {product.stock} left</p>
      )}
      {product.stock === 0 && (
        <p className="text-xs text-muted-foreground mt-1">Out of stock</p>
      )}
    </div>
  </Link>
);

export default ProductCard;
