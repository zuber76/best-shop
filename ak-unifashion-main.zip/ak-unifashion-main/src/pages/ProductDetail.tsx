import { useParams, Link } from 'react-router-dom';
import { useState } from 'react';
import { useStore } from '@/context/StoreContext';
import { Phone, MessageCircle } from 'lucide-react';
import { CATEGORIES } from '@/types/product';

const ProductDetail = () => {
  const { id } = useParams();
  const { products, contactInfo } = useStore();
  const product = products.find(p => p.id === id);
  const [activeImg, setActiveImg] = useState(0);

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-bold mb-4">Product not found</h1>
        <Link to="/categories" className="text-gold hover:text-gold-dark font-body">Back to shop</Link>
      </div>
    );
  }

  const cat = CATEGORIES.find(c => c.id === product.category);
  const whatsappMsg = encodeURIComponent(`Hi! I'm interested in ${product.name} ($${product.price})`);

  return (
    <div className="container mx-auto px-4 py-10">
      <nav className="text-sm text-muted-foreground mb-6 font-body">
        <Link to="/" className="hover:text-gold">Home</Link> / <Link to={`/category/${product.category}`} className="hover:text-gold">{cat?.name}</Link> / <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
        {/* Images */}
        <div>
          <div className="aspect-square overflow-hidden bg-secondary rounded-sm mb-3">
            <img src={product.images[activeImg]} alt={product.name} className="w-full h-full object-cover" />
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-2">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImg(i)}
                  className={`w-16 h-16 rounded-sm overflow-hidden border-2 transition-colors ${i === activeImg ? 'gold-border' : 'border-transparent'}`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold mb-2">{product.name}</h1>
          <p className="text-2xl text-gold font-body font-bold mb-4">${product.price.toFixed(2)}</p>
          <p className="text-muted-foreground font-body leading-relaxed mb-6">{product.description}</p>
          
          <div className="mb-6">
            <span className={`inline-block text-sm font-body px-3 py-1 rounded-sm ${product.stock > 0 ? 'bg-secondary text-foreground' : 'bg-destructive/10 text-destructive'}`}>
              {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
            </span>
          </div>

          <div className="space-y-3">
            <a
              href={`https://wa.me/${contactInfo.whatsapp.replace(/\D/g, '')}?text=${whatsappMsg}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full bg-[hsl(142,70%,40%)] text-primary-foreground py-3 px-6 font-body text-sm font-semibold tracking-wider uppercase hover:bg-[hsl(142,70%,35%)] transition-colors"
            >
              <MessageCircle className="h-4 w-4" /> Order via WhatsApp
            </a>
            <a
              href={`tel:${contactInfo.phone}`}
              className="flex items-center justify-center gap-2 w-full border-2 gold-border text-gold py-3 px-6 font-body text-sm font-semibold tracking-wider uppercase hover:bg-gold hover:text-accent-foreground transition-colors"
            >
              <Phone className="h-4 w-4" /> Call to Order
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
