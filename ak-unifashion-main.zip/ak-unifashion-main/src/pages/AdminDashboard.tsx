import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useStore } from '@/context/StoreContext';
import { CATEGORIES, Product } from '@/types/product';
import { Trash2, Edit, Plus, LogOut, Phone, Mail, MapPin } from 'lucide-react';

type Tab = 'products' | 'add' | 'contact';

const AdminDashboard = () => {
  const { isAdmin, logout } = useAuth();
  const { products, addProduct, updateProduct, deleteProduct, contactInfo, updateContactInfo } = useStore();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('products');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form state
  const emptyForm: { name: string; description: string; price: number; category: string; images: string[]; stock: number; featured: boolean } = { name: '', description: '', price: 0, category: CATEGORIES[0].id, images: [''], stock: 0, featured: false };
  const [form, setForm] = useState(emptyForm);
  const [contactForm, setContactForm] = useState(contactInfo);

  if (!isAdmin) {
    navigate('/admin/login');
    return null;
  }

  const handleSave = () => {
    if (!form.name || !form.price) return;
    const cleanImages = form.images.filter(i => i.trim());
    if (editingId) {
      updateProduct(editingId, { ...form, images: cleanImages });
      setEditingId(null);
    } else {
      addProduct({ ...form, images: cleanImages });
    }
    setForm(emptyForm);
    setTab('products');
  };

  const startEdit = (p: Product) => {
    setForm({ name: p.name, description: p.description, price: p.price, category: p.category, images: p.images, stock: p.stock, featured: p.featured });
    setEditingId(p.id);
    setTab('add');
  };

  const tabs: { id: Tab; label: string }[] = [
    { id: 'products', label: 'Products' },
    { id: 'add', label: editingId ? 'Edit Product' : 'Add Product' },
    { id: 'contact', label: 'Contact Info' },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-2xl font-bold">Admin Dashboard</h1>
        <button onClick={() => { logout(); navigate('/'); }} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-destructive font-body transition-colors">
          <LogOut className="h-4 w-4" /> Logout
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-8 border-b border-border">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => { setTab(t.id); if (t.id === 'add' && !editingId) { setForm(emptyForm); } }}
            className={`px-4 py-2 text-sm font-body font-medium border-b-2 transition-colors ${tab === t.id ? 'border-gold text-gold' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Products Tab */}
      {tab === 'products' && (
        <div>
          <button onClick={() => setTab('add')} className="mb-4 flex items-center gap-2 bg-gold text-accent-foreground px-4 py-2 text-sm font-body font-semibold hover:bg-gold-dark transition-colors">
            <Plus className="h-4 w-4" /> Add Product
          </button>
          <div className="overflow-x-auto">
            <table className="w-full text-sm font-body">
              <thead>
                <tr className="border-b border-border text-left">
                  <th className="py-3 pr-4">Image</th>
                  <th className="py-3 pr-4">Name</th>
                  <th className="py-3 pr-4">Category</th>
                  <th className="py-3 pr-4">Price</th>
                  <th className="py-3 pr-4">Stock</th>
                  <th className="py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map(p => (
                  <tr key={p.id} className="border-b border-border">
                    <td className="py-3 pr-4">
                      <img src={p.images[0]} alt="" className="w-12 h-12 object-cover rounded-sm" />
                    </td>
                    <td className="py-3 pr-4 font-medium">{p.name}</td>
                    <td className="py-3 pr-4 text-muted-foreground">{CATEGORIES.find(c => c.id === p.category)?.name}</td>
                    <td className="py-3 pr-4">${p.price}</td>
                    <td className="py-3 pr-4">{p.stock}</td>
                    <td className="py-3">
                      <div className="flex gap-2">
                        <button onClick={() => startEdit(p)} className="p-1.5 text-muted-foreground hover:text-gold transition-colors"><Edit className="h-4 w-4" /></button>
                        <button onClick={() => deleteProduct(p.id)} className="p-1.5 text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Tab */}
      {tab === 'add' && (
        <div className="max-w-lg space-y-4">
          <div>
            <label className="block text-sm font-body font-medium mb-1">Product Name</label>
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 border border-border bg-background text-sm font-body focus:outline-none focus:border-gold" />
          </div>
          <div>
            <label className="block text-sm font-body font-medium mb-1">Description</label>
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} className="w-full px-3 py-2 border border-border bg-background text-sm font-body focus:outline-none focus:border-gold" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-body font-medium mb-1">Price ($)</label>
              <input type="number" value={form.price} onChange={e => setForm({ ...form, price: Number(e.target.value) })} className="w-full px-3 py-2 border border-border bg-background text-sm font-body focus:outline-none focus:border-gold" />
            </div>
            <div>
              <label className="block text-sm font-body font-medium mb-1">Stock</label>
              <input type="number" value={form.stock} onChange={e => setForm({ ...form, stock: Number(e.target.value) })} className="w-full px-3 py-2 border border-border bg-background text-sm font-body focus:outline-none focus:border-gold" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-body font-medium mb-1">Category</label>
            <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 border border-border bg-background text-sm font-body focus:outline-none focus:border-gold">
              {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-body font-medium mb-1">Image URLs</label>
            {form.images.map((img, i) => (
              <div key={i} className="flex gap-2 mb-2">
                <input value={img} onChange={e => { const imgs = [...form.images]; imgs[i] = e.target.value; setForm({ ...form, images: imgs }); }} className="flex-1 px-3 py-2 border border-border bg-background text-sm font-body focus:outline-none focus:border-gold" placeholder="https://..." />
                {form.images.length > 1 && (
                  <button onClick={() => setForm({ ...form, images: form.images.filter((_, j) => j !== i) })} className="text-destructive text-sm">Remove</button>
                )}
              </div>
            ))}
            <button onClick={() => setForm({ ...form, images: [...form.images, ''] })} className="text-sm text-gold font-body hover:text-gold-dark">+ Add another image</button>
          </div>
          <label className="flex items-center gap-2 text-sm font-body">
            <input type="checkbox" checked={form.featured} onChange={e => setForm({ ...form, featured: e.target.checked })} className="accent-[hsl(38,50%,60%)]" />
            Featured product
          </label>
          <div className="flex gap-3 pt-2">
            <button onClick={handleSave} className="bg-gold text-accent-foreground px-6 py-2 text-sm font-body font-semibold hover:bg-gold-dark transition-colors">
              {editingId ? 'Update' : 'Add'} Product
            </button>
            {editingId && (
              <button onClick={() => { setEditingId(null); setForm(emptyForm); setTab('products'); }} className="px-6 py-2 text-sm font-body text-muted-foreground hover:text-foreground border border-border">
                Cancel
              </button>
            )}
          </div>
        </div>
      )}

      {/* Contact Tab */}
      {tab === 'contact' && (
        <div className="max-w-lg space-y-4">
          {[
            { label: 'Phone', key: 'phone' as const, icon: Phone },
            { label: 'WhatsApp', key: 'whatsapp' as const, icon: Phone },
            { label: 'Email', key: 'email' as const, icon: Mail },
            { label: 'Address', key: 'address' as const, icon: MapPin },
          ].map(f => (
            <div key={f.key}>
              <label className="block text-sm font-body font-medium mb-1">{f.label}</label>
              <input value={contactForm[f.key]} onChange={e => setContactForm({ ...contactForm, [f.key]: e.target.value })} className="w-full px-3 py-2 border border-border bg-background text-sm font-body focus:outline-none focus:border-gold" />
            </div>
          ))}
          <button onClick={() => updateContactInfo(contactForm)} className="bg-gold text-accent-foreground px-6 py-2 text-sm font-body font-semibold hover:bg-gold-dark transition-colors">
            Save Contact Info
          </button>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
