import { useParams, Link } from 'react-router-dom';
import { useStore } from '@/context/StoreContext';
import { CATEGORIES } from '@/types/product';
import ProductCard from '@/components/ProductCard';

const CategoryPage = () => {
  const { id } = useParams();
  const { products } = useStore();

  if (id) {
    const cat = CATEGORIES.find(c => c.id === id);
    const filtered = products.filter(p => p.category === id);
    return (
      <div className="container mx-auto px-4 py-10">
        <nav className="text-sm text-muted-foreground mb-6 font-body">
          <Link to="/" className="hover:text-gold">Home</Link> / <Link to="/categories" className="hover:text-gold">Shop</Link> / <span className="text-foreground">{cat?.name || id}</span>
        </nav>
        <h1 className="font-display text-3xl font-bold mb-8">{cat?.name || id}</h1>
        {filtered.length === 0 ? (
          <p className="text-muted-foreground font-body">No products in this category yet.</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {filtered.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </div>
    );
  }

  // All categories view
  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="font-display text-3xl font-bold mb-8">All Categories</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {CATEGORIES.map(cat => {
          const count = products.filter(p => p.category === cat.id).length;
          return (
            <Link key={cat.id} to={`/category/${cat.id}`} className="fashion-card p-8 text-center group">
              <span className="text-4xl block mb-3">{cat.icon}</span>
              <h3 className="font-display text-lg font-semibold group-hover:text-gold transition-colors">{cat.name}</h3>
              <p className="text-sm text-muted-foreground mt-1">{count} products</p>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default CategoryPage;
