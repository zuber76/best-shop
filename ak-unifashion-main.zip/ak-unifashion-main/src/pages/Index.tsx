import { Link } from 'react-router-dom';
import heroBanner from '@/assets/hero-banner.jpg';
import { useStore } from '@/context/StoreContext';
import { CATEGORIES } from '@/types/product';
import ProductCard from '@/components/ProductCard';

const Index = () => {
  const { products } = useStore();
  const featured = products.filter(p => p.featured).slice(0, 6);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative h-[70vh] min-h-[500px] overflow-hidden">
        <img src={heroBanner} alt="Fashion collection" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-primary/40" />
        <div className="relative container mx-auto px-4 h-full flex items-center">
          <div className="max-w-lg animate-fade-in">
            <p className="text-gold font-body text-sm tracking-[0.3em] uppercase mb-3">New Collection 2026</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold text-primary-foreground mb-4 leading-tight">
              Elegance Redefined
            </h1>
            <p className="text-primary-foreground/80 font-body mb-6">Discover our curated selection of premium fashion, accessories, and fragrances.</p>
            <Link
              to="/categories"
              className="inline-block bg-gold text-accent-foreground px-8 py-3 text-sm font-body font-semibold tracking-wider uppercase hover:bg-gold-dark transition-colors"
            >
              Shop Now
            </Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="font-display text-2xl md:text-3xl font-bold text-center mb-2">Shop by Category</h2>
        <p className="text-muted-foreground text-center mb-10 font-body text-sm">Find exactly what you're looking for</p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {CATEGORIES.map(cat => (
            <Link
              key={cat.id}
              to={`/category/${cat.id}`}
              className="fashion-card flex flex-col items-center justify-center p-6 text-center group"
            >
              <span className="text-3xl mb-3">{cat.icon}</span>
              <span className="font-body text-xs font-semibold tracking-wider uppercase group-hover:text-gold transition-colors">
                {cat.name}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section className="bg-secondary py-16">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-2xl md:text-3xl font-bold text-center mb-2">Featured Products</h2>
          <p className="text-muted-foreground text-center mb-10 font-body text-sm">Handpicked for you</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
            {featured.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
