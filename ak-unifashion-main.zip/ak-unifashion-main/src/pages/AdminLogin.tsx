import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { ShoppingBag } from 'lucide-react';

const AdminLogin = () => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login, isAdmin } = useAuth();
  const navigate = useNavigate();

  if (isAdmin) {
    navigate('/admin');
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(password)) {
      navigate('/admin');
    } else {
      setError('Invalid password');
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <ShoppingBag className="h-10 w-10 text-gold mx-auto mb-3" />
          <h1 className="font-display text-2xl font-bold">Admin Login</h1>
          <p className="text-sm text-muted-foreground font-body mt-1">Enter your admin password</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="password"
            value={password}
            onChange={e => { setPassword(e.target.value); setError(''); }}
            placeholder="Password"
            className="w-full px-4 py-3 border border-border bg-background font-body text-sm focus:outline-none focus:border-gold transition-colors"
          />
          {error && <p className="text-sm text-destructive font-body">{error}</p>}
          <button
            type="submit"
            className="w-full bg-primary text-primary-foreground py-3 font-body text-sm font-semibold tracking-wider uppercase hover:bg-primary/90 transition-colors"
          >
            Sign In
          </button>
          <p className="text-xs text-muted-foreground text-center font-body">Default password: admin123</p>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
