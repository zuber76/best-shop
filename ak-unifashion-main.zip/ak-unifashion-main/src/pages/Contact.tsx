import { Phone, MessageCircle, Mail, MapPin } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

const Contact = () => {
  const { contactInfo } = useStore();

  const items = [
    { icon: Phone, label: 'Phone', value: contactInfo.phone, href: `tel:${contactInfo.phone}` },
    { icon: MessageCircle, label: 'WhatsApp', value: contactInfo.whatsapp, href: `https://wa.me/${contactInfo.whatsapp.replace(/\D/g, '')}` },
    { icon: Mail, label: 'Email', value: contactInfo.email, href: `mailto:${contactInfo.email}` },
    { icon: MapPin, label: 'Address', value: contactInfo.address, href: null },
  ];

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="font-display text-3xl md:text-4xl font-bold text-center mb-2">Get in Touch</h1>
      <p className="text-muted-foreground text-center font-body mb-12">We'd love to hear from you</p>
      
      <div className="max-w-2xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-6">
        {items.map(item => (
          <div key={item.label} className="fashion-card p-6 text-center">
            <item.icon className="h-8 w-8 text-gold mx-auto mb-3" />
            <h3 className="font-display font-semibold mb-1">{item.label}</h3>
            {item.href ? (
              <a href={item.href} target={item.label === 'WhatsApp' ? '_blank' : undefined} className="text-sm text-muted-foreground hover:text-gold transition-colors font-body">
                {item.value}
              </a>
            ) : (
              <p className="text-sm text-muted-foreground font-body">{item.value}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Contact;
