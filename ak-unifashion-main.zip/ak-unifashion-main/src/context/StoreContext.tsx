import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, ContactInfo } from '@/types/product';
import { mockProducts, defaultContactInfo } from '@/data/mockData';

interface StoreContextType {
  products: Product[];
  contactInfo: ContactInfo;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  updateContactInfo: (info: ContactInfo) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider = ({ children }: { children: ReactNode }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('store_products');
    return saved ? JSON.parse(saved) : mockProducts;
  });

  const [contactInfo, setContactInfo] = useState<ContactInfo>(() => {
    const saved = localStorage.getItem('store_contact');
    return saved ? JSON.parse(saved) : defaultContactInfo;
  });

  useEffect(() => { localStorage.setItem('store_products', JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem('store_contact', JSON.stringify(contactInfo)); }, [contactInfo]);

  const addProduct = (product: Omit<Product, 'id'>) => {
    setProducts(prev => [...prev, { ...product, id: Date.now().toString() }]);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const updateContactInfo = (info: ContactInfo) => setContactInfo(info);

  return (
    <StoreContext.Provider value={{ products, contactInfo, addProduct, updateProduct, deleteProduct, updateContactInfo }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};
