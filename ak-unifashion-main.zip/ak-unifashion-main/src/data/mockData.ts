import { Product, ContactInfo } from '@/types/product';

export const mockProducts: Product[] = [
  {
    id: '1', name: 'Classic Leather Oxford', description: 'Handcrafted genuine leather oxford shoes with elegant stitching. Perfect for formal occasions.', price: 189,
    category: 'shoes', images: ['https://images.unsplash.com/photo-1614252369475-531eba835eb1?w=600', 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=600'], stock: 15, featured: true,
  },
  {
    id: '2', name: 'Suede Chelsea Boots', description: 'Premium suede chelsea boots with elastic side panels. Versatile for casual and semi-formal wear.', price: 220,
    category: 'shoes', images: ['https://images.unsplash.com/photo-1638247025967-b4e38f787b76?w=600'], stock: 8, featured: false,
  },
  {
    id: '3', name: 'Strappy Gold Sandals', description: 'Elegant gold-toned strappy sandals with cushioned insole. Perfect for summer evenings.', price: 95,
    category: 'sandals', images: ['https://images.unsplash.com/photo-1603487742131-4160ec999306?w=600'], stock: 20, featured: true,
  },
  {
    id: '4', name: 'Leather Slide Sandals', description: 'Minimalist leather slide sandals with contoured footbed for all-day comfort.', price: 75,
    category: 'sandals', images: ['https://images.unsplash.com/photo-1562273138-f46be4ebdf33?w=600'], stock: 25, featured: false,
  },
  {
    id: '5', name: 'Chronograph Gold Watch', description: 'Luxury chronograph watch with gold-plated case and genuine leather strap.', price: 450,
    category: 'watches', images: ['https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=600', 'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=600'], stock: 5, featured: true,
  },
  {
    id: '6', name: 'Minimalist Silver Watch', description: 'Clean minimalist design with Swiss movement and sapphire crystal glass.', price: 320,
    category: 'watches', images: ['https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=600'], stock: 10, featured: false,
  },
  {
    id: '7', name: 'Noir Eau de Parfum', description: 'A sophisticated blend of oud, amber, and vanilla notes. Long-lasting fragrance.', price: 135,
    category: 'perfumes', images: ['https://images.unsplash.com/photo-1541643600914-78b084683601?w=600'], stock: 30, featured: true,
  },
  {
    id: '8', name: 'Rose Garden Perfume', description: 'Delicate floral fragrance with Bulgarian rose and jasmine. A timeless classic.', price: 110,
    category: 'perfumes', images: ['https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?w=600'], stock: 18, featured: false,
  },
  {
    id: '9', name: 'Tailored Blazer Set', description: 'Professional tailored blazer and trouser set in premium wool blend.', price: 380,
    category: 'ladies-suits', images: ['https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600'], stock: 7, featured: true,
  },
  {
    id: '10', name: 'Slim Fit Chinos', description: 'Modern slim fit chinos in stretch cotton. Available in multiple colors.', price: 85,
    category: 'mens-pants-shirts', images: ['https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=600'], stock: 35, featured: true,
  },
  {
    id: '11', name: 'Oxford Button-Down Shirt', description: 'Classic oxford cloth button-down shirt in premium cotton.', price: 95,
    category: 'mens-pants-shirts', images: ['https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=600'], stock: 22, featured: false,
  },
];

export const defaultContactInfo: ContactInfo = {
  phone: '+91 7878597873',
  whatsapp: '+91 7878597873',
  email: 'mrzubr035@gmail.com',
  address: 'Kareem Nagar, Kho Nagoriyaan, Jaipur, Rajasthan',
};
